Put founder portrait, 4:5 (about 1000x1250px), JPG under 300KB.
Exact name: david-adeyileka.jpg
Names are lowercase and case-sensitive on GitHub. Delete this file if you like.
